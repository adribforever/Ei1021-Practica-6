package controlador;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import modelo.GestorViajes;

import java.io.IOException;

@WebServlet(name = "ServletAccede", value = "/ServletAccede")
public class ServletAccede extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        ServletContext contexto = getServletContext();
        GestorViajes gestor = (GestorViajes) contexto.getAttribute("gestor");
        if (gestor == null){
            gestor = new GestorViajes();
            contexto.setAttribute("gestor", gestor);
        }
        String codcli = request.getParameter("codcli");
        HttpSession sesion = request.getSession(true);
        sesion.setAttribute("codcli", codcli);
        response.setContentType("text/html");
        RequestDispatcher vista = request.getRequestDispatcher("menu.jsp");
        vista.forward(request, response);

    }
}

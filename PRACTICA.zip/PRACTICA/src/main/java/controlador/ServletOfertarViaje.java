package controlador;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import modelo.GestorViajes;
import org.json.simple.JSONObject;

import java.io.IOException;

@WebServlet(name = "ServletOfertarViaje", value = "/ServletOfertarViaje")
public class ServletOfertarViaje extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        ServletContext contexto = getServletContext();
        GestorViajes gestor = (GestorViajes) contexto.getAttribute("gestor");
        String origen = request.getParameter("origen");
        String destino = request.getParameter("destino");
        String fecha = request.getParameter("fecha");
        long precio = Long.parseLong(request.getParameter("precio"));
        long numplazas = Long.parseLong(request.getParameter("numplazas"));
        HttpSession sesion = request.getSession();
        String codcli = (String) sesion.getAttribute("codcli");
        if(codcli == null) {
            RequestDispatcher vista = request.getRequestDispatcher("index.html");
            vista.forward(request, response);
        }
        JSONObject viajeOfertado = gestor.ofertaViaje(codcli, origen, destino, fecha, precio, numplazas);
        request.setAttribute("viajeOfertado",viajeOfertado);
        response.setContentType("text/html");
        RequestDispatcher vista = request.getRequestDispatcher("respOfertaViaje.jsp");
        vista.forward(request, response);
    }
}


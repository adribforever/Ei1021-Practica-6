package es.uji.proyectoservlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "ServletDeBienvenida", value = "/ServletDeBienvenida")
public class ServletDeBienvenida extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");

        String nombre = request.getParameter("nombre");
        String apellidos = request.getParameter("apellidos");
        System.out.println("[LOG] Llamada a doPost con " + nombre + "" + apellidos);

        request.setAttribute("ruta", request.getContextPath());
        RequestDispatcher vista = request.getRequestDispatcher("Bienvenida.jsp");
        vista.forward(request,response);
    }
}

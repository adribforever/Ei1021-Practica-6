package controlador;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import modelo.GestorViajes;

import java.io.IOException;

@WebServlet(name = "ServletAnulaReserva", value = "/ServletAnulaReserva")
public class ServletAnulaReserva extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        ServletContext contexto = getServletContext();
        GestorViajes gestor = (GestorViajes) contexto.getAttribute("gestor");
        String codviaje = request.getParameter("codviaje");
        HttpSession sesion = request.getSession();
        String codcli = (String) sesion.getAttribute("codcli");
        String viajeAnulado = gestor.anulaReserva(codviaje, codcli).toJSONString();
        request.setAttribute("viajeAnulado",viajeAnulado);
        response.setContentType("text/html");
        RequestDispatcher vista = request.getRequestDispatcher("respAnulaReserva.jsp");
        vista.forward(request, response);
    }
}

package controlador;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import modelo.GestorViajes;
import org.json.simple.JSONObject;

import java.io.IOException;

@WebServlet(name = "ServletAnulaViaje", value = "/ServletAnulaViaje")
public class ServletBorraViaje extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        ServletContext contexto = getServletContext();
        GestorViajes gestor = (GestorViajes) contexto.getAttribute("gestor");
        String codviaje = request.getParameter("codviaje");
        HttpSession sesion = request.getSession();
        String codcli = (String) sesion.getAttribute("codcli");
        JSONObject viajeBorrado = gestor.borraViaje(codviaje, codcli);
        request.setAttribute("viajeBorrado",viajeBorrado);
        response.setContentType("text/html");
        RequestDispatcher vista = request.getRequestDispatcher("respBorraViaje.jsp");
        vista.forward(request, response);
    }
}

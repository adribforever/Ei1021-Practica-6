package controlador;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import modelo.GestorViajes;
import org.json.simple.JSONArray;

import java.io.IOException;

@WebServlet(name = "ServletConsultarViajes", value = "/ServletConsultarViajes")
public class ServletConsultarViajes extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        ServletContext contexto = getServletContext();
        GestorViajes gestor = (GestorViajes) contexto.getAttribute("gestor");
        String origen = request.getParameter("origen");
        JSONArray viajes = gestor.consultaViajes(origen);
        request.setAttribute("viajes", viajes);
        response.setContentType("text/html");
        RequestDispatcher vista = request.getRequestDispatcher("respConsultaViajes.jsp");
        vista.forward(request,response);
    }
}

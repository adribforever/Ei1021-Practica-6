package controlador;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import modelo.GestorViajes;

import java.io.IOException;

@WebServlet(name = "ServletGuardaDatos", value = "/ServletGuardaDatos")
public class ServletGuardaDatos extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContext contexto = getServletContext();
        GestorViajes gestor = (GestorViajes) contexto.getAttribute("gestor");
        gestor.guardaDatos();
        response.setContentType("text/html");
        RequestDispatcher vista = request.getRequestDispatcher("guardaDatos.jsp");
        vista.forward(request,response);
    }
}

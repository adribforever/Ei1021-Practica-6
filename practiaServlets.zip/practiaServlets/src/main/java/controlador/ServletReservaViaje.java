package controlador;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import modelo.GestorViajes;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.IOException;

@WebServlet(name = "ServletReservaViaje", value = "/ServletReservaViaje")
public class ServletReservaViaje extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        ServletContext contexto = getServletContext();
        GestorViajes gestor = (GestorViajes) contexto.getAttribute("gestor");
        String codviaje = request.getParameter("codviaje");
        HttpSession sesion = request.getSession();
        String codcli = (String) sesion.getAttribute("codcli");
        JSONObject viaje = gestor.reservaViaje(codviaje, codcli);
        request.setAttribute("viajeReservado", viaje);
        response.setContentType("text/html");
        RequestDispatcher vista = request.getRequestDispatcher("respReservaViaje.jsp");
        vista.forward(request,response);
    }
}
